import ReadQSRSoS as qsr
import ReadSquirrelSoS as squirrel

print(squirrel.get_check_data('55199741'))